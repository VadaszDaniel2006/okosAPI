const express = require("express"); // Express importálása
const fetch = require("node-fetch"); // Explicit import
const app = express(); // Express példányosítása
const port = 3000; // Port beállítása

// Middleware - köztes alkalmazások
app.use(express.json());

// Véletlenszerű válaszok a "Hogy vagy" kérdésre
const GREETING_RESPONSES = [
    "Nagyszerűen, köszönöm!",
    "Kiválóan érzem magam!",
    "Jól, köszönöm a kérdést!",
    "Csodásan!",
    "Fantasztikusan!",
    "Példásan!",
    "Remekül!",
    "Káprázatosan!",
    "Bámulatosan!",
    "Pompásan!"
];

let usedGreetings = [];

// 1. GET /api/time - pontos idő visszaadása
app.get('/api/time', (req, res) => {
    const now = new Date();
    const time = now.toLocaleTimeString('hu-HU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
    
    res.json({
        success: true,
        time: time,
        timestamp: now.toISOString()
    });
});

// 2. GET /api/date - mai dátum visszaadása
app.get('/api/date', (req, res) => {
    const today = new Date();
    const date = today.toLocaleDateString('hu-HU', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        weekday: 'long'
    });
    
    res.json({
        success: true,
        date: date,
        isoDate: today.toISOString().split('T')[0]
    });
});

// 3. GET /api/temp - Keszthely hőmérséklet visszaadása
app.get('/api/temp', async (req, res) => {
    try {
        // Keszthely koordinátái: 46.7681, 17.2432
        const fetch = (await import('node-fetch')).default;
        const response = await fetch('https://api.open-meteo.com/v1/forecast?latitude=46.7681&longitude=17.2432&current_weather=true');
        const weatherData = await response.json();
        
        res.json({
            success: true,
            location: "Keszthely",
            temperature: weatherData.current_weather.temperature,
            unit: "°C",
            windspeed: weatherData.current_weather.windspeed,
            time: weatherData.current_weather.time
        });
        
    } catch (error) {
        console.error('Hiba a hőmérséklet lekérésében:', error);
        res.status(500).json({
            success: false,
            error: "Nem sikerült lekérni a hőmérsékleti adatokat"
        });
    }
});

// 4. GET /api/greetings - véletlenszerű válasz a "Hogy vagy" kérdésre
app.get('/api/greetings', (req, res) => {
    // Ha már minden választ használtunk, reseteljük
    if (usedGreetings.length >= GREETING_RESPONSES.length) {
        usedGreetings = [];
    }
    
    // Választunk egy még nem használt választ
    let availableResponses = GREETING_RESPONSES.filter(
        response => !usedGreetings.includes(response)
    );
    
    const randomResponse = availableResponses[
        Math.floor(Math.random() * availableResponses.length)
    ];
    
    usedGreetings.push(randomResponse);
    
    res.json({
        success: true,
        question: "Hogy vagy?",
        answer: randomResponse,
        remainingResponses: GREETING_RESPONSES.length - usedGreetings.length
    });
});

// Fő oldal - API információk
app.get('/', (req, res) => {
    res.json({
        message: "OkosAPI szerver fut!",
        endpoints: {
            time: "/api/time",
            date: "/api/date",
            temperature: "/api/temp",
            greetings: "/api/greetings"
        }
    });
});

// A webszerver elindítása
app.listen(port, () => {
    console.log(`✅ OkosAPI szerver figyel a http://localhost:${port} webcímen`);
    console.log('📡 Elérhető végpontok:');
    console.log('   - GET /api/time');
    console.log('   - GET /api/date');
    console.log('   - GET /api/temp');
    console.log('   - GET /api/greetings');
});